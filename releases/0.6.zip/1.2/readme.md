## New Features and Bug Fixes for 1.2
1. Custom themes
2. Fixed loading bug
3. Added settings page
